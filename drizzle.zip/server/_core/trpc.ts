import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { isOwnerEmail } from "./supabaseAuth";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const superAdminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;
    if (!ctx.user || !isOwnerEmail(ctx.user.email)) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito ao proprietário." });
    }
    return next({ ctx: { ...ctx, user: ctx.user } });
  }),
);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || (ctx.user.role !== 'admin' && !isOwnerEmail(ctx.user.email))) {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);

/**
 * For company-scoped operations (menu, orders, inventory, finance,
 * integrations). Derives `companyId` from the authenticated admin's own
 * record — never from client input — so one company's admin can never read
 * or write another company's data by crafting a request.
 */
export const companyAdminProcedure = adminProcedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;
    if (!ctx.user?.companyId) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Conta não está vinculada a nenhuma empresa." });
    }
    return next({ ctx: { ...ctx, companyId: ctx.user.companyId } });
  }),
);
